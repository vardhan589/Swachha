package com.bhanu.swacha;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.capacitorjs.plugins.camera.CameraPlugin;
import com.capacitorjs.plugins.geolocation.GeolocationPlugin;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerPlugin(CameraPlugin.class);
        registerPlugin(GeolocationPlugin.class);
    }
}
