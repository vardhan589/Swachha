import { useState, useEffect, useRef, useCallback } from "react";
import axios from "axios";
import { Geolocation } from '@capacitor/geolocation';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

const WASTE_TYPES = ["Plastic", "Organic", "Construction", "Hazardous", "Mixed", "E-Waste"];

// ─── Map SVG Component ──────────────────────────────────────────────────────
function MapView({ reports, onPin, userLocation }) {
  const [hoveredPin, setHoveredPin] = useState(null);

  const latMin = 12.88, latMax = 13.05, lngMin = 77.56, lngMax = 77.73;
  const W = 680, H = 420;

  const toX = (lng) => ((lng - lngMin) / (lngMax - lngMin)) * (W - 60) + 30;
  const toY = (lat) => (1 - (lat - latMin) / (latMax - latMin)) * (H - 60) + 30;

  const gridLines = [];
  for (let i = 0; i <= 6; i++) {
    const x = 30 + (i / 6) * (W - 60);
    const y = 30 + (i / 6) * (H - 60);
    gridLines.push({ x, y });
  }

  return (
    <div className="map-container animate-slide-up">
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: "block" }}>
        {/* Dark futuristic grid */}
        {gridLines.map((g, i) => (
          <g key={i}>
            <line x1={g.x} y1="0" x2={g.x} y2={H} stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
            <line x1="0" y1={g.y} x2={W} y2={g.y} stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
          </g>
        ))}
        {/* Roads (stylized neon) */}
        <path d={`M${toX(77.59)} ${toY(12.97)} L${toX(77.63)} ${toY(12.97)} L${toX(77.65)} ${toY(13.0)}`} fill="none" stroke="rgba(56, 189, 248, 0.3)" strokeWidth="2" strokeLinecap="round" />
        <path d={`M${toX(77.595)} ${toY(12.93)} L${toX(77.595)} ${toY(13.01)}`} fill="none" stroke="rgba(56, 189, 248, 0.3)" strokeWidth="2" strokeLinecap="round" />
        <path d={`M${toX(77.56)} ${toY(12.96)} L${toX(77.72)} ${toY(12.96)}`} fill="none" stroke="rgba(16, 185, 129, 0.2)" strokeWidth="2" strokeLinecap="round" />

        <text x={toX(77.61)} y={toY(12.92)} textAnchor="middle" style={{ fontSize: 13, fill: "rgba(255,255,255,0.3)", fontFamily: "var(--font-heading)", fontWeight: 500, letterSpacing: "0.1em" }}>BENGALURU</text>

        {/* Pins */}
        {reports.map((r) => {
          const x = toX(r.lng), y = toY(r.lat);
          const isPending = r.status === "pending";
          const color = isPending ? "#ef4444" : "#10b981"; // modern red vs emerald
          const isHov = hoveredPin === r._id || hoveredPin === r.id;
          return (
            <g key={r._id || r.id} style={{ cursor: "pointer", transition: "all 0.3s" }}
              onMouseEnter={() => setHoveredPin(r._id || r.id)}
              onMouseLeave={() => setHoveredPin(null)}
              onClick={() => onPin(r)}>
              {/* Outer glow */}
              <circle cx={x} cy={y} r={isHov ? 18 : 12} fill={color} opacity={0.2} style={{ transition: "r 0.3s ease" }} />
              {/* Inner dot */}
              <circle cx={x} cy={y} r={isHov ? 8 : 6} fill={color} filter={isHov ? "drop-shadow(0 0 8px ${color})" : "none"} />
              <text x={x} y={y + 4} textAnchor="middle" style={{ fontSize: 10, fill: "#fff", fontFamily: "var(--font-heading)", fontWeight: 700 }}>
                {isPending ? "!" : "✓"}
              </text>
            </g>
          );
        })}

        {/* User location glowing pulse */}
        {userLocation && (
          <g style={{ animation: "float 3s ease-in-out infinite" }}>
            <circle cx={toX(userLocation.lng)} cy={toY(userLocation.lat)} r={16} fill="#3b82f6" opacity={0.2} />
            <circle cx={toX(userLocation.lng)} cy={toY(userLocation.lat)} r={7} fill="#3b82f6" filter="drop-shadow(0 0 10px #3b82f6)" />
            <circle cx={toX(userLocation.lng)} cy={toY(userLocation.lat)} r={3} fill="#fff" />
          </g>
        )}

        {/* Glassmorphic Tooltip inside SVG */}
        {hoveredPin && (() => {
          const r = reports.find(r => (r._id || r.id) === hoveredPin);
          if (!r) return null;
          const x = Math.min(toX(r.lng), W - 180), y = Math.max(toY(r.lat) - 80, 20);
          return (
            <g style={{ animation: "slideUp 0.2s ease forwards" }}>
              <rect x={x - 12} y={y - 8} width={180} height={64} rx="12" fill="rgba(15, 23, 42, 0.85)" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
              <text x={x} y={y + 12} style={{ fontSize: 13, fill: "#fff", fontFamily: "var(--font-heading)", fontWeight: 600 }}>{r.type} Waste</text>
              <text x={x} y={y + 28} style={{ fontSize: 11, fill: "#94a3b8", fontFamily: "var(--font-body)" }}>{r.address}</text>
              <text x={x} y={y + 44} style={{ fontSize: 11, fill: r.status === "pending" ? "#f87171" : "#34d399", fontFamily: "var(--font-heading)", fontWeight: 600, letterSpacing: "0.05em" }}>
                {r.status === "pending" ? "⚠ PENDING" : "✓ CLEANED"}
              </text>
            </g>
          );
        })()}
      </svg>

      {/* Legend Map overlay */}
      <div style={{ position: "absolute", bottom: 16, left: 16, display: "flex", gap: 16, background: "rgba(15, 23, 42, 0.7)", backdropFilter: "blur(8px)", borderRadius: "100px", border: "1px solid rgba(255,255,255,0.1)", padding: "8px 16px", fontSize: 12, fontWeight: 500 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 6, color: "#e2e8f0" }}>
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#ef4444", boxShadow: "0 0 8px #ef4444" }} /> Pending
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 6, color: "#e2e8f0" }}>
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#10b981", boxShadow: "0 0 8px #10b981" }} /> Cleaned
        </span>
        <span style={{ display: "flex", alignItems: "center", gap: 6, color: "#e2e8f0" }}>
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#3b82f6", boxShadow: "0 0 8px #3b82f6" }} /> You
        </span>
      </div>
    </div>
  );
}

// ─── Report Card ─────────────────────────────────────────────────────────────
function ReportCard({ report, onMarkCleaned, index }) {
  const isPending = report.status === "pending";
  const time = report.timestamp ? new Date(report.timestamp).getTime() : new Date(report.createdAt).getTime();
  const age = Math.round((Date.now() - time) / 3600000);
  const ageStr = age < 24 ? `${age}h ago` : `${Math.round(age / 24)}d ago`;

  return (
    <div className="glass-card animate-slide-up" style={{ padding: "16px 20px", display: "flex", gap: 16, alignItems: "center", animationDelay: `${index * 0.05}s` }}>
      <div style={{ width: 56, height: 56, borderRadius: "16px", background: isPending ? "linear-gradient(135deg, #fef2f2, #fee2e2)" : "linear-gradient(135deg, #ecfdf5, #d1fae5)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0, boxShadow: isPending ? "inset 0 2px 4px rgba(239,68,68,0.1)" : "inset 0 2px 4px rgba(16,185,129,0.1)" }}>
        {report.type === "Plastic" ? "🛍" : report.type === "Organic" ? "🍂" : report.type === "Construction" ? "🧱" : report.type === "Hazardous" ? "⚗️" : report.type === "E-Waste" ? "💻" : "🗑"}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <span className="heading-font" style={{ fontWeight: 600, fontSize: 16, color: "var(--color-text-main)" }}>{report.type} Waste</span>
          <span className="badge-tag" style={{ background: isPending ? "#fef2f2" : "#ecfdf5", color: isPending ? "#ef4444" : "#10b981", border: `1px solid ${isPending ? '#fecaca' : '#a7f3d0'}` }}>
            {isPending ? "PENDING" : "CLEANED"}
          </span>
        </div>
        <div style={{ fontSize: 13, color: "var(--color-text-muted)", marginBottom: 8, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          📍 {report.address} · <span style={{ opacity: 0.8 }}>{ageStr}</span>
        </div>
        <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
          <span style={{ fontSize: 13, color: "var(--color-text-muted)", fontWeight: 500 }}>👤 {report.reporter}</span>
          <span style={{ fontSize: 13, color: "var(--color-secondary)", fontWeight: 600, background: "rgba(16, 185, 129, 0.1)", padding: "2px 8px", borderRadius: "100px" }}>
            ✨ +{report.eco_karma} Karma
          </span>
        </div>
      </div>
      {isPending && (
        <button onClick={() => onMarkCleaned(report._id || report.id)}
          style={{ padding: "8px 16px", borderRadius: "100px", border: "1px solid var(--color-primary)", background: "var(--color-primary)", color: "white", cursor: "pointer", fontWeight: 600, fontSize: 13, transition: "all 0.2s", boxShadow: "var(--shadow-glow)" }}
          onMouseEnter={(e) => e.target.style.transform = "scale(1.05)"}
          onMouseLeave={(e) => e.target.style.transform = "scale(1)"}
        >
          Mark Clean
        </button>
      )}
    </div>
  );
}

// ─── New Report Modal ─────────────────────────────────────────────────────────
function NewReportModal({ userLocation, setUserLocation, onSubmit, onClose }) {
  const [wasteType, setWasteType] = useState(WASTE_TYPES[0]);
  const [photo, setPhoto] = useState(null);
  const [loading, setLoading] = useState(false);

  const handlePhoto = async () => {
    try {
      try {
        const perm = await Camera.checkPermissions();
        if (perm.camera !== 'granted' || perm.photos !== 'granted') {
          const req = await Camera.requestPermissions();
          if (req.camera !== 'granted' && req.photos !== 'granted') {
            alert("Camera permission denied.");
            return;
          }
        }
      } catch (permErr) {
        // Ignored on web
      }

      const image = await Camera.getPhoto({
        quality: 80,
        allowEditing: false,
        resultType: CameraResultType.Uri,
        source: CameraSource.Prompt
      });
      setPhoto(image.webPath);
    } catch (err) {
      console.log("Camera cancelled or failed", err);
      if (err && err.message !== 'User cancelled photos app' && err.message !== 'User cancelled camera app') {
        alert("Camera error: " + (err.message || "Unknown error"));
      }
    }
  };

  const handleSubmit = () => {
    setLoading(true);
    onSubmit({ wasteType, photo, location: userLocation }).finally(() => setLoading(false));
  };

  const handleGetLocation = async () => {
    try {
      try {
        const perm = await Geolocation.checkPermissions();
        if (perm.location !== 'granted') {
          const req = await Geolocation.requestPermissions();
          if (req.location !== 'granted') {
            alert("Location permission denied.");
            return;
          }
        }
      } catch (permErr) {
        // Ignored on web
      }
      const coordinates = await Geolocation.getCurrentPosition({ timeout: 10000, enableHighAccuracy: true });
      setUserLocation({
        lat: coordinates.coords.latitude,
        lng: coordinates.coords.longitude
      });
    } catch (err) {
      if (err.message === 'Timeout expired') {
        alert("Location request timed out. Please check your GPS signal or permissions.");
      } else {
        console.error("Error getting location", err);
        alert("Failed to get location. Please check permissions.");
      }
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
          <h2 style={{ margin: 0, fontSize: 24, background: "linear-gradient(to right, var(--color-primary), #3b82f6)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>New Report</h2>
          <button onClick={onClose} style={{ background: "rgba(0,0,0,0.05)", border: "none", width: 32, height: 32, borderRadius: "50%", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "background 0.2s" }} onMouseEnter={e => e.target.style.background = "rgba(0,0,0,0.1)"} onMouseLeave={e => e.target.style.background = "rgba(0,0,0,0.05)"}>✕</button>
        </div>

        <div className="glass-card" style={{ padding: "12px 16px", marginBottom: 20, display: "flex", gap: 12, alignItems: "center", background: "rgba(59, 130, 246, 0.05)", border: "1px solid rgba(59, 130, 246, 0.2)" }}>
          <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#3b82f6", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>📍</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, color: "var(--color-text-muted)", fontWeight: 500 }}>Live GPS Coordinates</div>
            <div className="heading-font" style={{ fontSize: 15, fontWeight: 600, color: "var(--color-text-main)", letterSpacing: "0.02em" }}>{userLocation ? `${userLocation.lat.toFixed(4)}°, ${userLocation.lng.toFixed(4)}°` : "Detecting..."}</div>
          </div>
          <button onClick={handleGetLocation} style={{ padding: "6px 12px", borderRadius: "8px", background: "var(--color-primary)", color: "white", border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>
            Get Location
          </button>
        </div>

        <div style={{ marginBottom: 24 }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: "var(--color-text-main)", display: "block", marginBottom: 12 }}>Waste Category</label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            {WASTE_TYPES.map(t => (
              <button key={t} onClick={() => setWasteType(t)}
                style={{ fontSize: 13, padding: "8px 16px", borderRadius: "100px", border: wasteType === t ? "none" : "1px solid var(--color-border)", background: wasteType === t ? "var(--color-primary)" : "transparent", color: wasteType === t ? "white" : "var(--color-text-muted)", cursor: "pointer", fontWeight: wasteType === t ? 600 : 500, transition: "all 0.2s", boxShadow: wasteType === t ? "var(--shadow-glow)" : "none" }}>
                {t}
              </button>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: 32 }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: "var(--color-text-main)", display: "block", marginBottom: 12 }}>Photo Evidence</label>
          <div onClick={handlePhoto}
            style={{ border: "2px dashed var(--color-border)", borderRadius: "var(--radius-lg)", padding: "24px", textAlign: "center", cursor: "pointer", background: photo ? "transparent" : "var(--color-background)", transition: "all 0.2s" }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "var(--color-primary)"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "var(--color-border)"}
          >
            {photo ? (
              <div style={{ animation: "fadeIn 0.3s ease" }}>
                <img src={photo} alt="preview" style={{ maxHeight: 120, borderRadius: "12px", boxShadow: "var(--shadow-md)" }} />
                <div style={{ fontSize: 13, color: "var(--color-primary)", fontWeight: 600, marginTop: 12 }}>✓ Image attached and optimized</div>
              </div>
            ) : (
              <div>
                <div style={{ width: 48, height: 48, background: "white", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, margin: "0 auto 12px", boxShadow: "var(--shadow-sm)" }}>📷</div>
                <div style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-main)" }}>Tap to open Camera</div>
                <div style={{ fontSize: 13, color: "var(--color-text-muted)", marginTop: 4 }}>Take a photo or choose from gallery</div>
              </div>
            )}
          </div>
        </div>

        <button className="btn-primary" onClick={handleSubmit} disabled={loading} style={{ width: "100%", padding: "16px", fontSize: 16 }}>
          {loading ? "Submitting Report..." : "Submit to Network"}
        </button>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("map");
  const [reports, setReports] = useState([]);
  const [userKarma, setUserKarma] = useState(0);
  const [userReports, setUserReports] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [selectedPin, setSelectedPin] = useState(null);
  const [userLocation, setUserLocation] = useState({ lat: 12.9716, lng: 77.5946 });
  const [toast, setToast] = useState(null);
  const [filter, setFilter] = useState("all");
  const [leaderboard, setLeaderboard] = useState([]);

  const API_URL = "http://127.0.0.1:5000/api";

  useEffect(() => {
    axios.get(`${API_URL}/reports`).then(res => setReports(res.data)).catch(console.error);
    axios.get(`${API_URL}/leaderboard`).then(res => setLeaderboard(res.data)).catch(console.error);
  }, []);

  const showToast = (msg) => {
    setToast({ msg });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    const fetchLocation = async () => {
      try {
        try {
          const perm = await Geolocation.checkPermissions();
          if (perm.location !== 'granted') {
            const req = await Geolocation.requestPermissions();
            if (req.location !== 'granted') {
              return;
            }
          }
        } catch (permErr) {
          // Ignored on web
        }
        const coordinates = await Geolocation.getCurrentPosition({ timeout: 10000, maximumAge: 3000, enableHighAccuracy: true });
        setUserLocation({
          lat: coordinates.coords.latitude,
          lng: coordinates.coords.longitude
        });
      } catch (err) {
        if (err.message !== 'Timeout expired') {
           console.log("Could not get initial location", err);
        }
      }
    };
    fetchLocation();
  }, []);

  const handleMarkCleaned = async (id) => {
    try {
      await axios.put(`${API_URL}/reports/${id}/clean`);
      setReports(prev => prev.map(r => (r._id || r.id) === id ? { ...r, status: "cleaned" } : r));
      setUserKarma(k => k + 30);
      setLeaderboard(prev => prev.map(u => u.name === "You" ? { ...u, karma: u.karma + 30 } : u));
      showToast("✨ Area Cleaned! +30 Eco-Karma");
      if (selectedPin && (selectedPin._id || selectedPin.id) === id) {
        setSelectedPin(prev => ({ ...prev, status: "cleaned" }));
      }
    } catch (err) {
      showToast("Failed to update status");
    }
  };

  const handleNewReport = async ({ wasteType, photo, location }) => {
    try {
      const payload = { lat: location.lat, lng: location.lng, type: wasteType, reporter: "You", address: "Live Coordinates, Bengaluru" };
      const res = await axios.post(`${API_URL}/reports`, payload);
      setReports(prev => [res.data, ...prev]);
      setUserKarma(k => k + 40);
      setUserReports(c => c + 1);

      const newLb = leaderboard.map(u => u.name === "You" ? { ...u, karma: u.karma + 40, reports: u.reports + 1 } : u);
      if (!newLb.find(u => u.name === "You")) newLb.push({ name: "You", karma: 40, reports: 1, badge: "🌾" });
      setLeaderboard(newLb);

      setShowModal(false);
      showToast(`🌿 Report Sent! +40 Eco-Karma`);
    } catch (err) {
      showToast("Failed to submit report");
    }
  };

  const filteredReports = reports.filter(r => filter === "all" ? true : r.status === filter);
  const badgeObj = userKarma >= 300 ? { l: "Eco Warrior", c: "linear-gradient(to right, #059669, #10b981)" } :
    userKarma >= 150 ? { l: "Green Guard", c: "linear-gradient(to right, #3b82f6, #0ea5e9)" } :
      userKarma >= 50 ? { l: "Eco Sprout", c: "linear-gradient(to right, #f59e0b, #fbbf24)" } :
        { l: "New Member", c: "linear-gradient(to right, #64748b, #94a3b8)" };

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "24px 16px 100px", minHeight: "100vh" }}>

      {/* Header */}
      <header className="animate-slide-up" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 32 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 4 }}>
            <div style={{ width: 40, height: 40, background: "var(--color-primary)", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, boxShadow: "var(--shadow-glow)" }}>
              🌍
            </div>
            <h1 style={{ margin: 0, fontSize: 28, fontWeight: 700, letterSpacing: "-0.03em" }}>Swachh Bharath</h1>
          </div>
          <p style={{ margin: 0, color: "var(--color-text-muted)", fontSize: 14, fontWeight: 500 }}>Global Environment Network</p>
        </div>

        <div className="glass-card" style={{ padding: "10px 16px", textAlign: "right", border: "1px solid rgba(16, 185, 129, 0.2)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, justifyContent: "flex-end" }}>
            <span style={{ fontSize: 28, fontWeight: 700, color: "var(--color-primary)", lineHeight: 1 }}>{userKarma}</span>
            <span style={{ fontSize: 20 }}>✨</span>
          </div>
          <div style={{ fontSize: 11, fontWeight: 600, color: "white", background: badgeObj.c, padding: "4px 10px", borderRadius: "100px", marginTop: 6, display: "inline-block", letterSpacing: "0.05em", textTransform: "uppercase" }}>
            {badgeObj.l}
          </div>
        </div>
      </header>

      {/* Tabs */}
      <nav className="glass-card animate-slide-up" style={{ display: "flex", padding: 6, marginBottom: 24, animationDelay: "0.1s" }}>
        {[
          { id: "map", label: "Interactive Map", icon: "🗺" },
          { id: "reports", label: "Live Feed", icon: "📋" },
          { id: "leaderboard", label: "Rankings", icon: "🏆" }
        ].map(t => (
          <button key={t.id} className={`tab-btn ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)} style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <span>{t.icon}</span> {t.label}
          </button>
        ))}
      </nav>

      {/* Content Area */}
      <main>
        {tab === "map" && (
          <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <MapView reports={reports} onPin={setSelectedPin} userLocation={userLocation} />
            {selectedPin && (
              <div style={{ marginTop: 24 }}>
                <h3 className="heading-font" style={{ fontSize: 15, color: "var(--color-text-muted)", marginBottom: 12 }}>Selected Report Details</h3>
                <ReportCard report={selectedPin} onMarkCleaned={(id) => { handleMarkCleaned(id); }} index={0} />
              </div>
            )}
          </div>
        )}

        {tab === "reports" && (
          <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
              {["all", "pending", "cleaned"].map(f => (
                <button key={f} className={`filter-btn ${filter === f ? 'active' : 'inactive'}`} onClick={() => setFilter(f)}>
                  {f === "all" ? "All Activity" : f === "pending" ? "Action Required" : "Successfully Cleaned"}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {filteredReports.length === 0 ? (
                <div className="glass-card" style={{ padding: 40, textAlign: "center", color: "var(--color-text-muted)" }}>No reports found in this category.</div>
              ) : (
                filteredReports.map((r, i) => <ReportCard key={r._id || r.id} report={r} onMarkCleaned={handleMarkCleaned} index={i} />)
              )}
            </div>
          </div>
        )}

        {tab === "leaderboard" && (
          <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
            {/* Hero Progress Card */}
            <div className="glass-card" style={{ padding: 24, marginBottom: 24, background: "linear-gradient(to bottom right, #ffffff, #f1f5f9)", border: "1px solid rgba(16, 185, 129, 0.2)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
                <div>
                  <h3 className="heading-font" style={{ margin: "0 0 4px", fontSize: 18, color: "var(--color-text-main)" }}>Your Impact Journey</h3>
                  <p style={{ margin: 0, fontSize: 14, color: "var(--color-text-muted)" }}>{userReports} total reports submitted</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <span style={{ fontSize: 32, fontWeight: 700, color: "var(--color-primary)" }}>{userKarma}</span>
                  <span style={{ fontSize: 14, color: "var(--color-text-muted)", marginLeft: 6 }}>/ 300 KP</span>
                </div>
              </div>
              <div className="progress-track">
                <div className="progress-fill" style={{ width: `${Math.min((userKarma / 300) * 100, 100)}%` }} />
              </div>
              <p style={{ fontSize: 13, color: "var(--color-secondary)", marginTop: 12, fontWeight: 500, margin: "12px 0 0" }}>
                {300 - userKarma > 0 ? `Earn ${300 - userKarma} more points to reach Eco Warrior status!` : "🏆 Maximum Rank Achieved!"}
              </p>
            </div>

            <h3 className="heading-font" style={{ fontSize: 15, color: "var(--color-text-muted)", marginBottom: 16 }}>Global Top Contributors</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[...leaderboard].sort((a, b) => b.karma - a.karma).map((u, i) => (
                <div key={u.name} className="glass-card" style={{ display: "flex", alignItems: "center", padding: "16px 20px", gap: 16, border: u.name === "You" ? "2px solid var(--color-primary)" : "1px solid var(--color-border)", transform: u.name === "You" ? "scale(1.02)" : "none", animation: `slideUp 0.4s ease forwards`, animationDelay: `${i * 0.1}s` }}>
                  <div style={{ width: 32, height: 32, borderRadius: "50%", background: i < 3 ? "var(--color-primary)" : "var(--color-background)", color: i < 3 ? "white" : "var(--color-text-muted)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 14 }}>
                    {i + 1}
                  </div>
                  <div style={{ fontSize: 28, filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.1))" }}>{u.badge}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 16, fontWeight: 600, color: "var(--color-text-main)" }}>{u.name}</div>
                    <div style={{ fontSize: 13, color: "var(--color-text-muted)" }}>{u.reports} Contributions</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 18, fontWeight: 700, color: "var(--color-text-main)" }}>{u.karma}</div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: "var(--color-primary)", letterSpacing: "0.05em", textTransform: "uppercase" }}>Karma</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Floating Action Button */}
      <div style={{ position: "fixed", bottom: 32, right: "clamp(32px, calc(50% - 360px + 32px), 50vw)", zIndex: 50 }}>
        <button className="btn-primary btn-fab" onClick={() => setShowModal(true)} title="Add Report">
          +
        </button>
      </div>

      {showModal && <NewReportModal userLocation={userLocation} setUserLocation={setUserLocation} onSubmit={handleNewReport} onClose={() => setShowModal(false)} />}

      {toast && (
        <div className="toast-msg">
          <span style={{ fontSize: 18 }}>🌱</span>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
